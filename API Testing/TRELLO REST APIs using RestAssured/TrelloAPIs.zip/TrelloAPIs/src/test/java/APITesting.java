import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APITesting {
    static String token = "aa979b45b0e4374f751fe7a750561efca20903f7eefc0094f3792b91292b262f";
    static String key = "a7018124e16577458ca39b0788e1c0bf";
    static String baseURL = "https://api.trello.com";
    static String myID = "623caaff30f94545a6a16abe";
    static String boardName = "APITesting";
    static String orgID;
    static String boardID;
    static String listID;

    public static void main(String[] args) {
       CreateOrganization();
       // GetMemberID();
       // CreateBoard();
       // getBoardsinORG();
       // createNewList();
       // getListinBoard();
     //   archivelist();
       // deleteBoard();
        deleteORG();
    }


    public static void CreateOrganization() {
        RestAssured.baseURI = baseURL;
        RestAssured.basePath = "/1/organizations";
        RequestSpecification request = RestAssured.given();
        request.queryParam("displayName", "Organization");
        request.queryParam("key", key);
        request.queryParam("token", token);
        request.header("Content-Type", "application/json");
        Response response = request.post();
        response.prettyPrint();
        JsonPath path = response.jsonPath();
        orgID = path.getString("id");
    }

    public static void GetMemberID() {
        RestAssured.baseURI = baseURL + "/1/members/" + myID + "/organizations";
        RequestSpecification request = RestAssured.given();
        request.queryParam("key", key);
        request.queryParam("token", token);
        request.header("Content-Type", "application/json");
        Response response = request.get();
        response.prettyPrint();
    }

    public static void CreateBoard() {
        Response respone = RestAssured.given().baseUri(baseURL)
                .basePath("/1/boards/")
                .header("Content-Type", "application/json")
                .queryParam("key", key)
                .queryParam("token", token)
                .queryParam("name", boardName)
                .queryParam("idOrganization", orgID)
                .when().post();
        boardID = respone.path("id");
    }

    public static void getBoardsinORG() {
        Response response = RestAssured
                .given()
                .baseUri(baseURL)
                .basePath("/1/organizations/" + orgID + "/boards")
                .queryParam("key", key)
                .queryParam("token", token)
                .header("Content-Type", "application/json")
                .when()
                .get();
        response.prettyPrint();
    }

    public static void createNewList() {
        //  https://api.trello.com/1/lists?name={name}&idBoard=5abbe4b7ddc1b351ef961414&key=APIKey&token=APIToken
        RestAssured.baseURI = baseURL + "/1/lists";
        RequestSpecification request = RestAssured.given();
        request.queryParam("name", "Review");
        request.queryParam("idBoard", boardID);
        request.queryParam("key", key);
        request.queryParam("token", token);
        request.header("Content-Type", "application/json");
        Response response = request.post();
//        response.prettyPrint();
        JsonPath path = response.jsonPath();
        listID = path.getString("id");
    }

    public static void getListinBoard() {
        //  https://api.trello.com/1/boards/{id}/lists?key=APIKey&token=APIToken
        RestAssured.baseURI = baseURL + "/1/boards/" + boardID + "/lists";
        RequestSpecification request = RestAssured.given();
        request.queryParam("key", key);
        request.queryParam("token", token);
        request.header("Content-Type", "application/json");
        Response response = request.get();
     //   response.prettyPrint();

    }

    public static void archivelist() {
        //https://api.trello.com/1/lists/{id}/closed?key=APIKey&token=APIToken
        RestAssured.baseURI = baseURL + "/1/lists/" + listID + "/closed";
        RequestSpecification request = RestAssured.given();
        request.queryParam("key", key);
        request.queryParam("token", token);
        request.queryParam("value", true);
        request.header("Content-Type", "application/json");
        Response response = request.put();
        response.prettyPrint();
    }
    public static void deleteBoard() {
        //https://api.trello.com/1/boards/{id}?key=APIKey&token=APIToken
        RestAssured.baseURI=baseURL+"/1/boards/"+boardID;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.queryParam("key",key);
        requestSpecification.queryParam("token",token);
        Response response=requestSpecification.delete();
     //   response.prettyPrint();
    }
    public static void deleteORG(){
        //https://api.trello.com/1/organizations/{id}?key=APIKey&token=APIToken
        RestAssured.baseURI=baseURL+"/1/organizations/"+orgID;
        RequestSpecification requestSpecification = RestAssured.given();
        requestSpecification.queryParam("key",key);
        requestSpecification.queryParam("token",token);
        requestSpecification.header("Content-Type", "application/json");
        requestSpecification.header("Accept","*/*");
        Response response=requestSpecification.delete();
        response.prettyPrint();
    }

}
